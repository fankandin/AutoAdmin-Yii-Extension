1. Copy all these to your web project's directory. [www] is DocumentRoot.
2. Import [importme.sql] (MySQL) dump.
3. Enter [http://yourtesthost/_admin/] and enjoy.

To try AutoAdmin's auth-system, in the config set 'authMode' to TRUE. Then next call of any 
 back-end's page will automatically redirect you to create the first root user.
