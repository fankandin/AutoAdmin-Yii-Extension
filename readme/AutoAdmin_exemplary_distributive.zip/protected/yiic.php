<?php
// change the following paths if necessary
$yiic=dirname(__FILE__).'/../../yii-1.1.10.r3566/framework/yiic.php';
$config=dirname(__FILE__).'/config/console.local.php';

require_once($yiic);
