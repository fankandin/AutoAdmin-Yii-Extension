<?php
$this->pageTitle = 'Back-end index page';

$this->breadcrumbs=array(
	$this->pageTitle
);
?>
<h1>AutoAdmin CMS FrameWork</h1>

<h2>Test sections</h2>
<ul>
	<li><a href="./test/continents/">Countries by continents</a></li>
	<li><a href="./test/countries/">All countries</a></li>
</ul>

<br clear="both"/>