-- MySQL dump 10.13  Distrib 5.1.45, for Win32 (ia32)
--
-- Host: localhost    Database: autoadmin_test
-- ------------------------------------------------------
-- Server version	5.1.45-community

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

CREATE DATABASE IF NOT EXISTS `autoadmin_test` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `autoadmin_test`;

--
-- Table structure for table `aa_access`
--

DROP TABLE IF EXISTS `aa_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aa_access` (
  `user_id` smallint(5) unsigned NOT NULL,
  `interface_id` smallint(5) unsigned NOT NULL,
  `read` tinyint(1) NOT NULL DEFAULT '0',
  `add` tinyint(1) NOT NULL DEFAULT '0',
  `edit` tinyint(1) NOT NULL DEFAULT '0',
  `delete` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_id`,`interface_id`),
  KEY `interface_id` (`interface_id`),
  CONSTRAINT `aa_access_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `aa_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `aa_access_ibfk_2` FOREIGN KEY (`interface_id`) REFERENCES `aa_interfaces` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aa_access`
--

LOCK TABLES `aa_access` WRITE;
/*!40000 ALTER TABLE `aa_access` DISABLE KEYS */;
/*!40000 ALTER TABLE `aa_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aa_authorizations`
--

DROP TABLE IF EXISTS `aa_authorizations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aa_authorizations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` smallint(5) unsigned NOT NULL,
  `when_enter` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ip` varchar(15) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `when_enter` (`when_enter`),
  CONSTRAINT `aa_authorizations_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `aa_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aa_authorizations`
--

LOCK TABLES `aa_authorizations` WRITE;
/*!40000 ALTER TABLE `aa_authorizations` DISABLE KEYS */;
/*!40000 ALTER TABLE `aa_authorizations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aa_errors`
--

DROP TABLE IF EXISTS `aa_errors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aa_errors` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `error_type` enum('exception','warning') DEFAULT NULL,
  `info` text,
  `authorization_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `authorization_id` (`authorization_id`),
  CONSTRAINT `aa_errors_ibfk_1` FOREIGN KEY (`authorization_id`) REFERENCES `aa_authorizations` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aa_errors`
--

LOCK TABLES `aa_errors` WRITE;
/*!40000 ALTER TABLE `aa_errors` DISABLE KEYS */;
/*!40000 ALTER TABLE `aa_errors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aa_interfaces`
--

DROP TABLE IF EXISTS `aa_interfaces`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aa_interfaces` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `section_id` tinyint(3) unsigned DEFAULT NULL,
  `alias` varchar(60) NOT NULL,
  `level` tinyint(3) unsigned NOT NULL DEFAULT '5',
  `title` varchar(80) NOT NULL,
  `info` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`),
  KEY `section_id` (`section_id`),
  CONSTRAINT `aa_interfaces_ibfk_1` FOREIGN KEY (`section_id`) REFERENCES `aa_sections` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aa_interfaces`
--

LOCK TABLES `aa_interfaces` WRITE;
/*!40000 ALTER TABLE `aa_interfaces` DISABLE KEYS */;
/*!40000 ALTER TABLE `aa_interfaces` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aa_logs`
--

DROP TABLE IF EXISTS `aa_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aa_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `interface_id` smallint(5) unsigned DEFAULT NULL,
  `authorization_id` int(10) unsigned DEFAULT NULL,
  `when_event` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `message` text,
  `data` text,
  PRIMARY KEY (`id`),
  KEY `interface_id` (`interface_id`),
  KEY `authorization_id` (`authorization_id`),
  CONSTRAINT `aa_logs_ibfk_1` FOREIGN KEY (`interface_id`) REFERENCES `aa_interfaces` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `aa_logs_ibfk_2` FOREIGN KEY (`authorization_id`) REFERENCES `aa_authorizations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aa_logs`
--

LOCK TABLES `aa_logs` WRITE;
/*!40000 ALTER TABLE `aa_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `aa_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aa_sections`
--

DROP TABLE IF EXISTS `aa_sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aa_sections` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aa_sections`
--

LOCK TABLES `aa_sections` WRITE;
/*!40000 ALTER TABLE `aa_sections` DISABLE KEYS */;
/*!40000 ALTER TABLE `aa_sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aa_users`
--

DROP TABLE IF EXISTS `aa_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aa_users` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `level` enum('root','admin','user') NOT NULL DEFAULT 'user',
  `login` varchar(21) NOT NULL,
  `password` varchar(32) NOT NULL,
  `interface_level` tinyint(4) NOT NULL DEFAULT '1',
  `email` varchar(40) NOT NULL,
  `surname` varchar(21) NOT NULL,
  `firstname` varchar(21) NOT NULL,
  `middlename` varchar(21) DEFAULT NULL,
  `regdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `info` tinytext,
  `salt` varchar(8) DEFAULT NULL,
  `disabled` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `login` (`login`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aa_users`
--

LOCK TABLES `aa_users` WRITE;
/*!40000 ALTER TABLE `aa_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `aa_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `continents`
--

DROP TABLE IF EXISTS `continents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `continents` (
  `id` varchar(15) NOT NULL,
  `name_en` varchar(16) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='Континенты';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `continents`
--

LOCK TABLES `continents` WRITE;
/*!40000 ALTER TABLE `continents` DISABLE KEYS */;
INSERT INTO `continents` VALUES ('africa','Africa'),('asia','Asia'),('australia','Australia'),('europe','Europe'),('n-america','North America'),('s-america','South America');
/*!40000 ALTER TABLE `continents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `countries`
--

DROP TABLE IF EXISTS `countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `countries` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `continent_id` varchar(15) NOT NULL,
  `name_en` varchar(60) DEFAULT NULL,
  `flag` varchar(160) DEFAULT NULL,
  `flag_ico` varchar(160) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `continent_id` (`continent_id`),
  CONSTRAINT `countries_ibfk_1` FOREIGN KEY (`continent_id`) REFERENCES `continents` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=197 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='Страны';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `countries`
--

LOCK TABLES `countries` WRITE;
/*!40000 ALTER TABLE `countries` DISABLE KEYS */;
INSERT INTO `countries` VALUES (1,'europe','Russia','russia.png','russia.png'),(2,'europe','Ukraine','ukraine.png','ukraine.png'),(3,'europe','Austria','austria.png','austria.png'),(4,'europe','Albania','albania.png','albania.png'),(5,'europe','Andorra','andorra.png','andorra.png'),(6,'europe','Belarus','belarus.png','belarus.png'),(7,'europe','Belgium','belgium.png','belgium.png'),(8,'europe','Bulgaria','bulgaria.png','bulgaria.png'),(9,'europe','Bosnia and Herzegovina','bosnia.png','bosnia.png'),(10,'europe','Vatican City','vatikan.png','vatikan.png'),(11,'europe','Great Britain','greatbritain.png','greatbritain.png'),(12,'europe','Hungary','hungary.png','hungary.png'),(13,'europe','Germany','germany.png','germany.png'),(14,'europe','Greece','greece.png','greece.png'),(15,'europe','Denmark','denmark.png','denmark.png'),(16,'europe','Ireland','ireland.png','ireland.png'),(17,'europe','Iceland','iceland.png','iceland.png'),(18,'europe','Spain','spain.png','spain.png'),(19,'europe','Italy','italy.png','italy.png'),(20,'europe','Kazakhstan','kazakhstan.png','kazakhstan.png'),(21,'europe','Latvia','latvia.png','latvia.png'),(22,'europe','Lithuania','lithuania.png','lithuania.png'),(23,'europe','Liechtenstein','liechtenstein.png','liechtenstein.png'),(24,'europe','Luxembourg','luxembourg.png','luxembourg.png'),(25,'europe','Malta','malta.png','malta.png'),(26,'europe','Maсedonia','macedonia.png','macedonia.png'),(27,'europe','Moldova','moldova.png','moldova.png'),(28,'europe','Monaco','monako.png','monako.png'),(29,'europe','Netherlands','netherlands.png','netherlands.png'),(30,'europe','Norway','norway.png','norway.png'),(31,'europe','Poland','poland.png','poland.png'),(32,'europe','Portugal','portugal.png','portugal.png'),(33,'europe','Romania','romania.png','romania.png'),(34,'europe','San Marino','san-marino.png','san-marino.png'),(35,'europe','Serbia','serbia.png','serbia.png'),(36,'europe','Slovakia','slovakia.png','slovakia.png'),(37,'europe','Slovenia','slovenia.png','slovenia.png'),(38,'europe','Turkey','turkey.png','turkey.png'),(39,'europe','Finland','finland.png','finland.png'),(40,'europe','France','france.png','france.png'),(41,'europe','Croatia','croatia.png','croatia.png'),(42,'europe','Montenegro','montenegro.png','montenegro.png'),(43,'europe','Czech Republic','czech.png','czech.png'),(44,'europe','Switzerland','switzerland.png','switzerland.png'),(45,'europe','Sweden','sweden.png','sweden.png'),(46,'europe','Estonia','estonia.png','estonia.png'),(47,'s-america','France Guiana','franceguiana.png','franceguiana.png'),(48,'s-america','Chile','chile.png','chile.png'),(49,'s-america','Ecuador','ecuador.png','ecuador.png'),(50,'s-america','South Georgia and the South Sandwich Islands','southgeorgia.png','southgeorgia.png'),(51,'asia','Armenia','armenia.png','armenia.png'),(52,'asia','Azerbaijan','azerbaijan.png','azerbaijan.png'),(53,'asia','Afghanistan','afganistan.png','afganistan.png'),(54,'asia','Bangladesh','bangladesh.png','bangladesh.png'),(55,'asia','Bahrain','bahreyn.png','bahreyn.png'),(56,'asia','Brunei Darussalam','bruney.png','bruney.png'),(57,'asia','Bhutan','butan.png','butan.png'),(58,'asia','East Timor','east-timor.png','east-timor.png'),(59,'asia','Vietnam','vetnam.png','vetnam.png'),(60,'europe','Georgia','georgia.png','georgia.png'),(62,'asia','India','indiya.png','indiya.png'),(63,'asia','Indonesia','indoneziya.png','indoneziya.png'),(64,'asia','Jordan','iordaniya.png','iordaniya.png'),(65,'asia','Iraq','iraq.png','iraq.png'),(66,'asia','Iran','iran.png','iran.png'),(67,'asia','Yemen','yemen.png','yemen.png'),(69,'asia','Cambodia','kambodzha.png','kambodzha.png'),(70,'asia','Qatar','qatar.png','qatar.png'),(71,'asia','Cyprus','cyprus.png','cyprus.png'),(72,'asia','Kyrgyzstan','kyrgyzstan.png','kyrgyzstan.png'),(73,'asia','China','china.png','china.png'),(74,'asia','North Korea','kndr.png','kndr.png'),(75,'asia','Kuwait','kuveyt.png','kuveyt.png'),(76,'asia','Laos','laos.png','laos.png'),(77,'asia','Lebanon','livan.png','livan.png'),(78,'asia','Malaysia','malayziya.png','malayziya.png'),(79,'asia','Maldives','maldivi.png','maldivi.png'),(80,'asia','Mongolia','mongoliya.png','mongoliya.png'),(81,'asia','Myanmar','myanma.png','myanma.png'),(82,'asia','Nepal','nepal.png','nepal.png'),(83,'asia','United Arab Emirates','oae.png','oae.png'),(84,'asia','Oman','oman.png','oman.png'),(85,'asia','Pakistan','pakistan.png','pakistan.png'),(86,'asia','Palestina','palestina.png','palestina.png'),(87,'asia','Saudi Arabia','saudiarabia.png','saudiarabia.png'),(88,'asia','Syria','siriya.png','siriya.png'),(89,'asia','Singapore','singapore.png','singapore.png'),(90,'asia','Tajikistan','tajikistan.png','tajikistan.png'),(91,'asia','Tailand','tailand.png','tailand.png'),(92,'asia','Turkmeniya','turkmeniya.png','turkmeniya.png'),(93,'asia','Uzbekistan','uzbekistan.png','uzbekistan.png'),(94,'asia','Philippines','filippini.png','filippini.png'),(95,'asia','Sri Lanka','sri-lanka.png','sri-lanka.png'),(96,'asia','Korea','korea.png','korea.png'),(97,'asia','Japan','japan.png','japan.png'),(98,'africa','Algeria','algeria.png','algeria.png'),(99,'africa','Egypt','egipet.png','egipet.png'),(100,'africa','Libya','liviya.png','liviya.png'),(101,'africa','Morocco','marokko.png','marokko.png'),(102,'africa','Sudan','sudan.png','sudan.png'),(103,'africa','Tunisia','tunis.png','tunis.png'),(105,'africa','Ceuta','seuta.png','seuta.png'),(106,'africa','Madeira','madeira.png','madeira.png'),(107,'africa','Melilla','melilya.png','melilya.png'),(108,'africa','Benin','benin.png','benin.png'),(109,'africa','Burkina Faso','burkina_faso.png','burkina_faso.png'),(110,'africa','Gambia','gambiya.png','gambiya.png'),(111,'africa','Ghana','gana.png','gana.png'),(112,'africa','Guinea','gvineya.png','gvineya.png'),(113,'africa','Guinea - Bissau','gvineya-bisau.png','gvineya-bisau.png'),(114,'africa','Cape Verde','kabo-verde.png','kabo-verde.png'),(115,'africa','Ivory Coast','ivorycoast.png','ivorycoast.png'),(116,'africa','Liberia','liberiya.png','liberiya.png'),(117,'africa','Mali','mali.png','mali.png'),(118,'africa','Mauritania','mavritaniya.png','mavritaniya.png'),(119,'africa','Niger','niger.png','niger.png'),(120,'africa','Nigeria','nigeria.png','nigeria.png'),(122,'africa','Senegal','senegal.png','senegal.png'),(123,'africa','Sierra Leone','sierra-leone.png','sierra-leone.png'),(124,'africa','Togo','togo.png','togo.png'),(125,'africa','Angola','angola.png','angola.png'),(126,'africa','Gabon','gabon.png','gabon.png'),(127,'africa','Cameroon','kamerun.png','kamerun.png'),(128,'africa','Democratic Republic of the Congo','drk.png','drk.png'),(129,'africa','Republic of the Congo','kongo.png','kongo.png'),(130,'africa','Sao Tome and Principe','sao-tome-principe.png','sao-tome-principe.png'),(131,'africa','Central African Republic','car.png','car.png'),(132,'africa','Chad','chad.png','chad.png'),(133,'africa','Equatorial Guinea','equatorial-guinea.png','equatorial-guinea.png'),(134,'africa','Burundi','burundi.png','burundi.png'),(135,'africa','Djibouti','dzhibuti.png','dzhibuti.png'),(136,'africa','Zambia','zambiya.png','zambiya.png'),(137,'africa','Zimbabwe','zimbabve.png','zimbabve.png'),(138,'africa','Kenya','keniya.png','keniya.png'),(139,'africa','Comoros','comoros.png','comoros.png'),(140,'africa','Mauritius','mavrikiy.png','mavrikiy.png'),(141,'africa','Madagascar','madagaskar.png','madagaskar.png'),(142,'africa','Malawi','malavi.png','malavi.png'),(143,'africa','Mozambique','mozambik.png','mozambik.png'),(144,'africa','Rwanda','ruanda.png','ruanda.png'),(145,'africa','Seychelles','seychelles.png','seychelles.png'),(146,'africa','Somalia','somali.png','somali.png'),(147,'africa','Somali','somalilend.png','somalilend.png'),(148,'africa','Tanzania','tanzaniya.png','tanzaniya.png'),(149,'africa','Uganda','uganda.png','uganda.png'),(150,'africa','Eritrea','eritreya.png','eritreya.png'),(151,'africa','Ethiopia','ethiopia.png','ethiopia.png'),(152,'africa','Botswana','botsvana.png','botsvana.png'),(153,'africa','Lesotho','lesoto.png','lesoto.png'),(154,'africa','Namibia','namibiya.png','namibiya.png'),(156,'africa','Swaziland','svazilend.png','svazilend.png'),(157,'africa','South Africa','sudafricana.png','sudafricana.png'),(158,'n-america','Belize','belize.png','belize.png'),(159,'n-america','Guatemala','guatemala.png','guatemala.png'),(160,'n-america','Honduras','honduras.png','honduras.png'),(161,'n-america','Costa Rica','costa_rica.png','costa_rica.png'),(162,'n-america','Nicaragua','nicaragua.png','nicaragua.png'),(163,'n-america','Panama','panama.png','panama.png'),(164,'n-america','El Salvador','salvador.png','salvador.png'),(165,'n-america','Cuba','cuba.png','cuba.png'),(166,'n-america','Mexico','mexico.png','mexico.png'),(167,'n-america','Canada','canada.png','canada.png'),(168,'n-america','USA','usa.png','usa.png'),(169,'europe','England','england.png','england.png'),(170,'europe','Scotland','scotland.png','scotland.png'),(171,'europe','Wales','wales.png','wales.png'),(172,'europe','Northern Ireland','north_ireland.png','north_ireland.png'),(173,'australia','Australia','australia.png','australia.png'),(174,'australia','New Zealand','newzeland.png','newzeland.png'),(175,'australia','Solomon Islands','solomon_islands.png','solomon_islands.png'),(176,'australia','Marshall Islands','marshall_islands.png','marshall_islands.png'),(177,'australia','Vanuatu','vanuatu.png','vanuatu.png'),(178,'s-america','Argentina','argentina.png','argentina.png'),(179,'s-america','Bolivia','bolivia.png','bolivia.png'),(180,'s-america','Brazil','brazil.png','brazil.png'),(181,'s-america','Venezuela','venezuela.png','venezuela.png'),(182,'s-america','Guyana','guyana.png','guyana.png'),(183,'s-america','Colombia','colombia.png','colombia.png'),(184,'s-america','Paraguay','paraguay.png','paraguay.png'),(185,'s-america','Peru','peru.png','peru.png'),(186,'s-america','Surinam','surinam.png','surinam.png'),(187,'s-america','Uruguay','uruguay.png','uruguay.png'),(188,'europe','Israel','israel.png','israel.png'),(189,'n-america','Jamaica','jamaica.png','jamaica.png'),(195,'europe','Faroe Islands','faroe.png','faroe.png'),(196,'australia','Saint Vincent and the Grenadines',NULL,NULL);
/*!40000 ALTER TABLE `countries` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2012-09-30 15:27:22
